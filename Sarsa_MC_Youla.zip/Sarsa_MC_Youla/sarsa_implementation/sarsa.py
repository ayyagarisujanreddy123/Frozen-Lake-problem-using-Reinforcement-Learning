import numpy as np
import gym

def sarsa(
    env,
    num_episodes=20000,
    alpha=0.1,        
    gamma=0.9,      
    epsilon=1.0,     
    epsilon_decay=0.9,
    epsilon_min=0.1):

    n_states = env.observation_space.n
    n_actions = env.action_space.n
    Q = np.zeros((n_states, n_actions))
    
    rewards_per_episode = []

    for episode in range(num_episodes):
        # Environment reset
        state, _ = env.reset()

        action = epsilon_greedy(Q, state, epsilon, n_actions)

        total_reward = 0
        terminated = False
        truncated = False

        while not (terminated or truncated):
    
            next_state, reward, terminated, truncated, _ = env.step(action)

            next_action = epsilon_greedy(Q, next_state, epsilon, n_actions)

            Q[state, action] += alpha * (
                reward
                + gamma * Q[next_state, next_action]
                - Q[state, action])

            state = next_state
            action = next_action
            total_reward += reward

        if epsilon > epsilon_min:
            epsilon *= epsilon_decay

        rewards_per_episode.append(total_reward)
    
    return Q, rewards_per_episode

def epsilon_greedy(Q, state, epsilon, n_actions):
    if np.random.rand() < epsilon:
        return np.random.randint(n_actions)  # random action
    else:
        return np.argmax(Q[state, :])