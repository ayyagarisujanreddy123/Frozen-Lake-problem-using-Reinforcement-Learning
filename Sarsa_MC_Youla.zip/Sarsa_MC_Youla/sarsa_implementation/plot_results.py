import matplotlib.pyplot as plt

episodes = list(range(1, 1001))  
rewards = [0 for _ in episodes]  

plt.figure(figsize=(8, 4))
plt.plot(episodes, rewards, label="Reward per Episode", color="blue", linewidth=2)
plt.xlabel("Episode (count)")
plt.ylabel("Reward (units)")
plt.title("SARSA Learning Curve on Custom 8x8 Frozen Lake")
plt.legend()
plt.grid(True)
plt.show()
