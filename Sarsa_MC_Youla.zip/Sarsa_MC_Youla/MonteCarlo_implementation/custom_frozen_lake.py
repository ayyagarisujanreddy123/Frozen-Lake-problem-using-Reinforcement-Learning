import gym
import numpy as np
from gym import spaces
from gym.envs.registration import register

class FrozenLakeCustom8x8(gym.Env):
    def __init__(self):
        super(FrozenLakeCustom8x8, self).__init__()
        self.action_space = spaces.Discrete(4)
        self.observation_space = spaces.Discrete(64)
        self.state = 0
        self.max_steps = 200 # maximum number of steps per episode.
        self.steps_taken = 0

    def reset(self, seed=None, options=None):
        if seed is not None:
            self.seed(seed)
        self.state = 0 # reset      
        self.steps_taken = 0 
        return self.state, {}

    def step(self, action):
        self.steps_taken += 1
        row, col = divmod(self.state, 8)

        if action == 0:      # Left
            new_row, new_col = row, col - 1
        elif action == 1:    # Down
            new_row, new_col = row + 1, col
        elif action == 2:    # Right
            new_row, new_col = row, col + 1
        elif action == 3:    # Up
            new_row, new_col = row - 1, col
        else:
            raise ValueError("Invalid action.")

       
        if new_row < 0 or new_row >= 8 or new_col < 0 or new_col >= 8:
            new_row, new_col = row, col

        self.state = new_row * 8 + new_col
        step_penalty = -0.01

        if self.state == 63:
            reward = 1.0  
            terminated = True
        else:
            reward = step_penalty
            terminated = False

        truncated = self.steps_taken >= self.max_steps
        info = {}

        return self.state, reward, terminated, truncated, info


register(
    id='FrozenLakeCustom-8x8-v0',
    entry_point='custom_frozen_lake:FrozenLakeCustom8x8',
    max_episode_steps=200
)
