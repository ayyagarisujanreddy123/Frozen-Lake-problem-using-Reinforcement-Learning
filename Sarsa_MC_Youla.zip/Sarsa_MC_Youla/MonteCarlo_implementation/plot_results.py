import matplotlib.pyplot as plt

def plot_rewards(rewards, num_episodes, title="Learning Curve"):
    """
    Plots the rewards per episode.

    Parameters:
        rewards (list or array): Total reward per episode.
        num_episodes (int): Number of episodes.
        title (str): Plot title.
    """
    plt.figure(figsize=(8, 4))
    plt.plot(range(1, num_episodes + 1), rewards, label="Reward per Episode", color="blue", linewidth=2)
    plt.xlabel("Episode (count)")
    plt.ylabel("Reward (units)")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()


