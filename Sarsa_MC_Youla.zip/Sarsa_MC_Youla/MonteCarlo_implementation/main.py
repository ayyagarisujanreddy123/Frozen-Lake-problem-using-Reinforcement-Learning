import numpy as np
if not hasattr(np, "bool8"):
    np.bool8 = np.bool_
import gym
from custom_frozen_lake import FrozenLakeCustom8x8
from monte_carlo import monte_carlo
from plot_results import plot_rewards

def main():
    
    env = gym.make('FrozenLakeCustom-8x8-v0')

    num_episodes = 20000
    alpha = 0.1
    gamma = 0.9
    epsilon = 1.0
    epsilon_decay = 0.9
    epsilon_min = 0.1

    Q, rewards = monte_carlo(env,
                             num_episodes=num_episodes,
                             alpha=alpha,
                             gamma=gamma,
                             epsilon=epsilon,
                             epsilon_decay=epsilon_decay,
                             epsilon_min=epsilon_min)
    
    
    plot_rewards(rewards, num_episodes, title="Monte Carlo Learning Curve on Custom 8x8 Frozen Lake")

if __name__ == "__main__":
    main()
