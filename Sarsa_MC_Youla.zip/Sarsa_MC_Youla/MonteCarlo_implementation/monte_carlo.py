import numpy as np

def monte_carlo(
    env,
    num_episodes=20000,
    alpha=0.1,       
    gamma=0.9,       
    epsilon=1.0,      
    epsilon_decay=0.9,
    epsilon_min=0.1
):
    """
    Monte Carlo control using an epsilon-greedy policy.
    Updates Q(s,a) after each complete episode.
    """
    n_states = env.observation_space.n
    n_actions = env.action_space.n
    
    Q = np.zeros((n_states, n_actions))
    
    rewards_per_episode = []

    for episode in range(num_episodes):
        
        episode_transitions = []
        state, _ = env.reset()
        done = False
        truncated = False
        total_reward = 0
        
        while not (done or truncated):
            # epsilon-greedy action slelection
            action = epsilon_greedy(Q, state, epsilon, n_actions)
            next_state, reward, done, truncated, _ = env.step(action)
            episode_transitions.append((state, action, reward))
            state = next_state
            total_reward += reward

        if epsilon > epsilon_min:
            epsilon *= epsilon_decay

        # update at every visit
        G = 0  
        for t in reversed(range(len(episode_transitions))):
            s, a, r = episode_transitions[t]
            G = gamma * G + r
            Q[s, a] += alpha * (G - Q[s, a])
        
        rewards_per_episode.append(total_reward)
    
    return Q, rewards_per_episode

def epsilon_greedy(Q, state, epsilon, n_actions):
    """
    Epsilon-greedy policy: select a random action with probability epsilon,
    otherwise select the action with the highest Q-value.
    """
    if np.random.rand() < epsilon:
        return np.random.randint(n_actions)
    else:
        return np.argmax(Q[state])
